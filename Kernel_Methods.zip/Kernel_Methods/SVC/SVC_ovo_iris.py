import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import ovo as OVO
import numpy as np
from sklearn import datasets

iris = datasets.load_iris()
X = iris.data
y = iris.target

# 初始化 One-vs-One 分类器，传入SVC的参数
ovo_classifier1 = OVO.ovo(C=1.0, kernel='linear')
ovo_classifier2 = OVO.ovo(C=1.0, kernel='rbf', γ=0.1)

from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score

# 初始化5折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 存储每次折叠的准确率
cv1_scores = []
cv2_scores = []

# 开始5折交叉验证
for fold, (train_index, test_index) in enumerate(kf.split(X), 1):
    print(f"Fold {fold}")
    # 分割训练集和验证集
    X_fold_train, X_fold_test = X[train_index], X[test_index]
    y_fold_train, y_fold_test = y[train_index], y[test_index]
    scaler = StandardScaler()
    X_fold_train = scaler.fit_transform(X_fold_train)
    X_fold_test = scaler.transform(X_fold_test)
    # 训练模型
    ovo_classifier1.fit(X_fold_train, y_fold_train)
    ovo_classifier2.fit(X_fold_train, y_fold_train)
    # mean_accuracy_tc, std_accuracy_tc = ovo_classifier1.cross_val_score(X_fold_train, y_fold_train, cv=5) # 调参用，类内部实现了训练集和验证集的5折交叉验证
    # 预测并计算准确率
    y1_pred = ovo_classifier1.predict(X_fold_test)
    y2_pred = ovo_classifier2.predict(X_fold_test)

    accuracy1 = accuracy_score(y_fold_test, y1_pred)
    accuracy2 = accuracy_score(y_fold_test, y2_pred)

    cv1_scores.append(accuracy1)
    cv2_scores.append(accuracy2)
# # 输出每次折叠的准确率
# print("Cross-validation scores:", cv_scores)

# 计算平均准确率及其标准差
mean_accuracy1 = np.mean(cv1_scores)
std_accuracy1 = np.std(cv1_scores)
print(f"C=1的线性核SVC: {mean_accuracy1:.3f} (+/- {std_accuracy1 * 2:.3f})")

mean_accuracy2=np.mean(cv2_scores)
std_accuracy2=np.std(cv2_scores)
print(f"C=1,γ=0.1的RBF核SVC: {mean_accuracy2:.3f} (+/- {std_accuracy2 * 2:.3f})")



