import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import ovr as OVR
import numpy as np
import os
import matplotlib.pyplot as plt

# 设置pandas显示选项，确保完整显示所有列和行
pd.set_option('display.max_columns', None)  # 显示所有列
pd.set_option('display.max_rows', None)     # 显示所有行
pd.set_option('display.width', None)        # 自动检测宽度
pd.set_option('display.expand_frame_repr', False)  # 防止DataFrame换行显示

# 定义特征名称
feature_names = [
    'REGION-CENTROID-COL', 'REGION-CENTROID-ROW', 'REGION-PIXEL-COUNT',
    'SHORT-LINE-DENSITY-5', 'SHORT-LINE-DENSITY-2', 'VEDGE-MEAN',
    'VEDGE-SD', 'HEDGE-MEAN', 'HEDGE-SD', 'INTENSITY-MEAN',
    'RAWRED-MEAN', 'RAWBLUE-MEAN', 'RAWGREEN-MEAN', 'EXRED-MEAN',
    'EXBLUE-MEAN', 'EXGREEN-MEAN', 'VALUE-MEAN', 'SATURATION-MEAN',
    'HUE-MEAN'
]

# 指定数据文件的路径
data_folder = r'E:\my_project\Kernel_Methods\image_segmentation'

# 读取训练数据，跳过前两行
train_data = pd.read_csv(f'{data_folder}/segmentation.data', skiprows=2, header=0, names=['CLASS'] + feature_names)

# 读取测试数据，跳过前两行
test_data = pd.read_csv(f'{data_folder}/segmentation.test', skiprows=2, header=0, names=['CLASS'] + feature_names)

data = pd.concat([train_data, test_data], axis=0).reset_index(drop=True)

# print(data.head())

# 将类别标签转换为数值
label_encoder = LabelEncoder()
data['CLASS'] = label_encoder.fit_transform(data['CLASS'])

# 分离特征和标签
X = data.drop('CLASS', axis=1)
y = data['CLASS'] # 7个类别，19个属性

print(X.shape,y.shape)
# print(y)

# 将 X 转换为 NumPy 数组
X = X.to_numpy()
y = y.to_numpy()

# 创建输出目录
output_dir = './output_ovr_image_segmentation'
os.makedirs(output_dir, exist_ok=True)

# 使用 train_test_split 函数将数据集分为 8:2 的比例,分出测试集
X, X_test, y, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 超参数 C 值的不同选择
C_values = [0.0001, 0.001, 0.1, 1, 10, 100]

# 用于存储每个 C 值的准确率和标准差
accuracy_scores = []
accuracy_std_devs = []


# 5 折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 继续分出验证集进行调参
for C in C_values:
    fold_accuracies = []

    for train_index, val_index in kf.split(X):
        # 分割训练集和验证集
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]

        # 特征缩放
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_val = scaler.transform(X_val)


        ovr_classifier = OVR.ovr(C=C, kernel='linear')

        # 训练模型
        ovr_classifier.fit(X_train, y_train)

        # 预测并计算准确率
        y_pred = ovr_classifier.predict(X_val)
        accuracy = accuracy_score(y_val, y_pred)
        fold_accuracies.append(accuracy)

    # 计算当前 C 值下的平均准确率和标准差
    accuracy_scores.append(np.mean(fold_accuracies))
    accuracy_std_devs.append(np.std(fold_accuracies))  # 计算标准差

# 绘制 C 与准确率之间的关系图
plt.figure(figsize=(8, 6))
plt.plot(C_values, accuracy_scores, marker='o', linestyle='-', color='b', label='Accuracy')
plt.fill_between(C_values,
                 np.array(accuracy_scores) - np.array(accuracy_std_devs),
                 np.array(accuracy_scores) + np.array(accuracy_std_devs),
                 color='b', alpha=0.2, label='Standard Deviation')  # 绘制误差带
plt.xscale('log')  # 使用对数尺度
plt.xlabel('C (log scale)')
plt.ylabel('Accuracy')
plt.title('Accuracy vs C for One-vs-Rest SVC (Linear Kernel) with Standard Deviation')
plt.grid(True)

output_path = os.path.join(output_dir, 'accuracy_vs_C_linear_with_std.png')
plt.savefig(output_path)

# 显示图像
plt.show()

# 提示图片保存路径
print(f"图像已保存到: {output_path}")

# 超参数 gamma 值的不同选择
gamma_values = [0.0001, 0.001, 0.01, 0.05,0.1,0.5, 1, 10, 100]

# 用于存储每个 gamma 值的准确率和标准差
accuracy_scores = []
accuracy_std_devs = []

# 继续分出验证集进行调参
for gamma in gamma_values:
    fold_accuracies = []

    for train_index, val_index in kf.split(X):
        # 分割训练集和验证集
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]

        # 特征缩放
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_val = scaler.transform(X_val)


        ovr_classifier = OVR.ovr(C=1, kernel='rbf', γ=gamma)

        # 训练模型
        ovr_classifier.fit(X_train, y_train)

        # 预测并计算准确率
        y_pred = ovr_classifier.predict(X_val)
        accuracy = accuracy_score(y_val, y_pred)
        fold_accuracies.append(accuracy)

    # 计算当前 gamma 值下的平均准确率和标准差
    accuracy_scores.append(np.mean(fold_accuracies))
    accuracy_std_devs.append(np.std(fold_accuracies))  # 计算标准差

# 绘制 gamma 与准确率之间的关系图
plt.figure(figsize=(8, 6))
plt.plot(gamma_values, accuracy_scores, marker='o', linestyle='-', color='b', label='Accuracy')
plt.fill_between(gamma_values,
                 np.array(accuracy_scores) - np.array(accuracy_std_devs),
                 np.array(accuracy_scores) + np.array(accuracy_std_devs),
                 color='b', alpha=0.2, label='Standard Deviation')  # 绘制误差带
plt.xscale('log')  # 使用对数尺度
plt.xlabel('Gamma (log scale)')
plt.ylabel('Accuracy')
plt.title('Accuracy vs Gamma for One-vs-Rest SVC with C=1 and RBF Kernel with Standard Deviation')
plt.grid(True)

output_path = os.path.join(output_dir, 'accuracy_vs_gamma_rbf_with_std.png')
plt.savefig(output_path)

# 显示图像
plt.show()

# 提示图片保存路径
print(f"图像已保存到: {output_path}")
