import numpy as np

# 核函数：常用的核函数有线性核、高斯RBF核、多项式核和Sigmoid核
def linear_kernel(X, Y):
    return np.dot(X, Y.T)

def rbf_kernel(X, Y, gamma=1.0):
    # RBF kernel (Gaussian Kernel)
    sq_dists = np.sum(X**2, axis=1).reshape(-1, 1) + np.sum(Y**2, axis=1) - 2 * np.dot(X, Y.T)
    return np.exp(-gamma * sq_dists)

def polynomial_kernel(X, Y, degree=3, coef0=1):
    # Polynomial kernel
    return (np.dot(X, Y.T) + coef0) ** degree

def sigmoid_kernel(X, Y, gamma=1.0, coef0=1):
    # Sigmoid kernel
    return np.tanh(gamma * np.dot(X, Y.T) + coef0)

# 核PCA实现
class kpca:
    def __init__(self, kernel='rbf', gamma=1.0, n_components=100, degree=2, coef0=0.1):
        self.kernel = kernel
        self.gamma = gamma
        self.n_components = n_components
        self.degree = degree
        self.coef0 = coef0

    def fit(self, X):
        # 计算内积矩阵（Gram矩阵）
        if self.kernel == 'rbf':
            K = rbf_kernel(X, X, gamma=self.gamma)
        elif self.kernel == 'linear':
            K = linear_kernel(X, X)
        elif self.kernel == 'poly':
            K = polynomial_kernel(X, X, degree=self.degree, coef0=self.coef0)
        elif self.kernel == 'sigmoid':
            K = sigmoid_kernel(X, X, gamma=self.gamma, coef0=self.coef0)
        else:
            raise ValueError("Unsupported kernel")

        # 中心化内积矩阵 K
        N = K.shape[0]
        one_n = np.ones((N, N)) / N
        K_centered = K - one_n.dot(K) - K.dot(one_n) + one_n.dot(K).dot(one_n)

        # 计算特征值和特征向量
        eigvals, eigvecs = np.linalg.eigh(K_centered)

        # 排序特征值，并选择前n个主成分
        sorted_indices = np.argsort(eigvals)[::-1]  # 降序排序
        eigvals = eigvals[sorted_indices]
        eigvecs = eigvecs[:, sorted_indices]

        # 选择前n个特征向量（对应最大的n个特征值）
        self.alphas = eigvecs[:, :self.n_components]
        self.lambdas = eigvals[:self.n_components]

    def transform(self, X):
        # 使用学习到的特征向量进行投影
        if self.kernel == 'rbf':
            K = rbf_kernel(X, self.X_train, gamma=self.gamma)
        elif self.kernel == 'linear':
            K = linear_kernel(X, self.X_train)
        elif self.kernel == 'poly':
            K = polynomial_kernel(X, self.X_train, degree=self.degree, coef0=self.coef0)
        elif self.kernel == 'sigmoid':
            K = sigmoid_kernel(X, self.X_train, gamma=self.gamma, coef0=self.coef0)
        else:
            raise ValueError("Unsupported kernel")

        return K.dot(self.alphas)

    def fit_transform(self, X):
        self.X_train = X
        self.fit(X)
        return self.transform(X)

