import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
import KPCA
import os
from sklearn.preprocessing import StandardScaler

# 加载Iris数据集
iris = datasets.load_iris()
X = iris.data
y = iris.target

# 标准化数据
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 核PCA实现
kpca = KPCA.kpca(kernel='rbf', gamma=1)  # 选择降到2D以便可视化
X_kpca = kpca.fit_transform(X)

# 输出目录
output_dir = './output_iris'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)


# 可视化降维后的数据
def plot_kpca(X_kpca, y, title, filename):
    plt.figure(figsize=(8, 6))
    if X_kpca.shape[1] > 1:  # 确保有至少两个主成分
        plt.scatter(X_kpca[:, 0], X_kpca[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
        plt.title(title)
        plt.xlabel('First Principal Component')
        plt.ylabel('Second Principal Component')
        plt.colorbar(label='Class Label')
    else:
        print(f"无法绘制2D图，因为降维结果只有一个主成分。")
    plt.savefig(filename)
    plt.close()


# 可视化原始数据与核PCA降维后的数据对比
def plot_original_vs_kpca(X, X_kpca, y):
    fig, ax = plt.subplots(1, 2, figsize=(14, 6))

    # 原始数据的二维可视化（选择前两个特征）
    ax[0].scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
    ax[0].set_title("Original Data (First 2 Features)")
    ax[0].set_xlabel('Feature 1')
    ax[0].set_ylabel('Feature 2')

    # 核PCA降维后的数据可视化
    ax[1].scatter(X_kpca[:, 0], X_kpca[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
    ax[1].set_title("Kernel PCA (2D Projection)")
    ax[1].set_xlabel('1st Principal Component')
    ax[1].set_ylabel('2nd Principal Component')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'original_vs_kpca.png'))
    plt.close()


# 绘制不同核函数的效果对比
kernels = ['rbf', 'linear', 'poly', 'sigmoid']
for kernel in kernels:
    kpca = KPCA.kpca(kernel=kernel, gamma=1)
    X_kpca = kpca.fit_transform(X)
    plot_kpca(X_kpca, y, f"Kernel PCA with {kernel} kernel", f"kpca_{kernel}.png")


# 画出主成分贡献图（特征值可视化）
def plot_eigenvalues(kpca, filename):
    plt.figure(figsize=(8, 6))
    plt.plot(np.arange(1, len(kpca.lambdas) + 1), kpca.lambdas, marker='o', linestyle='--')
    plt.title('Eigenvalues of Kernel PCA')
    plt.xlabel('Principal Component Index')
    plt.ylabel('Eigenvalue')
    plt.grid(True)
    plt.savefig(os.path.join(output_dir, filename))
    plt.close()


# # 绘制主成分贡献图
# plot_eigenvalues(kpca, 'kpca_eigenvalues.png')

def plot_sorted_eigenvalues(kpca, output_dir, filename):
    # 排序特征值，按从大到小排序
    sorted_indices = np.argsort(kpca.lambdas)[::-1]  # 获取按特征值大小排序的索引
    sorted_eigenvalues = np.sort(kpca.lambdas)[::-1]  # 排序特征值

    # 创建一个图表，显示排序后的特征值和它们的索引
    plt.figure(figsize=(8, 6))
    plt.plot(np.arange(1, len(sorted_eigenvalues) + 1), sorted_eigenvalues, marker='o', linestyle='--')
    plt.title('Eigenvalues of Kernel PCA (Sorted)')
    plt.xlabel('Principal Component Index')
    plt.ylabel('Eigenvalue')
    plt.grid(True)

    # 保存图像
    plt.savefig(os.path.join(output_dir, filename))
    plt.close()

# 示例用法
# kpca: 已经训练好的Kernel PCA对象
# output_dir: 保存图像的文件夹路径
# filename: 保存图像的文件名
kpca = KPCA.kpca(kernel='rbf', gamma=1)
X_kpca = kpca.fit_transform(X)
plot_sorted_eigenvalues(kpca, output_dir, 'sorted_eigenvalues.png')

pca = KPCA.kpca(kernel='linear', n_components=2)
X_pca = pca.fit_transform(X)
plot_kpca(X_pca, y, "PCA (Linear Kernel)", "pca_comparison.png")

# 显示原始数据和降维后的数据对比
plot_original_vs_kpca(X, X_kpca, y)

# 设置不同的gamma值
gamma_values = [0.1, 1.0, 10.0, 100.0]


# 遍历不同的gamma值
for gamma in gamma_values:
    # 创建并训练KPCA模型
    kpca_model = KPCA.kpca(kernel='rbf', gamma=gamma, n_components=2)
    X_kpca = kpca_model.fit_transform(X)

    # 绘制并保存图像
    title = f"Kernel PCA with RBF Kernel (gamma={gamma})"
    filename = os.path.join(output_dir, f"kpca_rbf_gamma_{gamma}.png")
    plot_kpca(X_kpca, y, title, filename)

# 设置不同的degree和coef0值
degree_values = [2, 3, 4]  # 多项式的度数
coef0_values = [1, 2, 3]   # 多项式核的常数项

# 遍历不同的degree和coef0值
for degree in degree_values:
    for coef0 in coef0_values:
        # 创建并训练KPCA模型
        kpca_model = KPCA.kpca(kernel='poly', degree=degree, coef0=coef0, n_components=2)
        X_kpca = kpca_model.fit_transform(X)

        # 绘制并保存图像
        title = f"Kernel PCA with Polynomial Kernel (degree={degree}, coef0={coef0})"
        filename = os.path.join(output_dir, f"kpca_polynomial_degree_{degree}_coef0_{coef0}.png")
        plot_kpca(X_kpca, y, title, filename)

print(f"Generated {len(degree_values) * len(coef0_values)} images in the '{output_dir}' folder.")