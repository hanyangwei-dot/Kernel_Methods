import numpy as np


# 核函数：线性核、RBF核、多项式核和Sigmoid核（已给出）
def linear_kernel(X, Y):
    return np.dot(X, Y.T)


def rbf_kernel(X, Y, gamma=1.0):
    sq_dists = np.sum(X ** 2, axis=1).reshape(-1, 1) + np.sum(Y ** 2, axis=1) - 2 * np.dot(X, Y.T)
    return np.exp(-gamma * sq_dists)


def polynomial_kernel(X, Y, degree=3, coef0=1):
    return (np.dot(X, Y.T) + coef0) ** degree


def sigmoid_kernel(X, Y, gamma=1.0, coef0=1):
    return np.tanh(gamma * np.dot(X, Y.T) + coef0)


# KLDA实现
class klda:
    def __init__(self, kernel='rbf', gamma=0.1, degree=2, coef0=0.1, n_components=19):
        self.kernel = kernel
        self.gamma = gamma
        self.degree = degree
        self.coef0 = coef0
        self.n_components = n_components

    def fit(self, X, y):
        # 计算内积矩阵（Gram矩阵）
        if self.kernel == 'rbf':
            K = rbf_kernel(X, X, gamma=self.gamma)
        elif self.kernel == 'linear':
            K = linear_kernel(X, X)
        elif self.kernel == 'poly':
            K = polynomial_kernel(X, X, degree=self.degree, coef0=self.coef0)
        elif self.kernel == 'sigmoid':
            K = sigmoid_kernel(X, X, gamma=self.gamma, coef0=self.coef0)
        else:
            raise ValueError("Unsupported kernel")

        N = X.shape[0]
        # 类标签的唯一值
        classes = np.unique(y)

        # 计算类内散度矩阵 S_W 和 类间散度矩阵 S_B
        mean_K = np.mean(K, axis=0)
        S_W = np.zeros((N, N))
        S_B = np.zeros((N, N))

        for c in classes:
            X_c = X[y == c]
            K_c = K[y == c, :]
            mean_c = np.mean(K_c, axis=0)
            S_W += np.dot((K_c - mean_c).T, (K_c - mean_c))
            N_c = X_c.shape[0]
            mean_diff = (mean_c - mean_K).reshape(-1, 1)
            S_B += N_c * np.dot(mean_diff, mean_diff.T)

        # 求解广义特征值问题 S_W^{-1} S_B
        eigvals, eigvecs = np.linalg.eigh(np.linalg.pinv(S_W).dot(S_B))
        # 选择前n个特征向量作为KLDA的投影
        sorted_indices = np.argsort(eigvals)[::-1]
        eigvals = eigvals[sorted_indices]
        eigvecs = eigvecs[:, sorted_indices]
        self.alphas = eigvecs[:, :self.n_components]

    def transform(self, X):
        # 计算新的数据点在KLDA空间中的表示
        if self.kernel == 'rbf':
            K = rbf_kernel(X, self.X_train, gamma=self.gamma)
        elif self.kernel == 'linear':
            K = linear_kernel(X, self.X_train)
        elif self.kernel == 'poly':
            K = polynomial_kernel(X, self.X_train, degree=self.degree, coef0=self.coef0)
        elif self.kernel == 'sigmoid':
            K = sigmoid_kernel(X, self.X_train, gamma=self.gamma, coef0=self.coef0)
        else:
            raise ValueError("Unsupported kernel")

        return np.dot(K, self.alphas)

    def fit_transform(self, X, y):
        self.X_train = X
        self.fit(X, y)
        return self.transform(X)
