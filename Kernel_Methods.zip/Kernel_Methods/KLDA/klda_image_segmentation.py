import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import KLDA
import numpy as np
import matplotlib.pyplot as plt
import os

# 设置pandas显示选项，确保完整显示所有列和行
pd.set_option('display.max_columns', None)  # 显示所有列
pd.set_option('display.max_rows', None)     # 显示所有行
pd.set_option('display.width', None)        # 自动检测宽度
pd.set_option('display.expand_frame_repr', False)  # 防止DataFrame换行显示

# 定义特征名称
feature_names = [
    'REGION-CENTROID-COL', 'REGION-CENTROID-ROW', 'REGION-PIXEL-COUNT',
    'SHORT-LINE-DENSITY-5', 'SHORT-LINE-DENSITY-2', 'VEDGE-MEAN',
    'VEDGE-SD', 'HEDGE-MEAN', 'HEDGE-SD', 'INTENSITY-MEAN',
    'RAWRED-MEAN', 'RAWBLUE-MEAN', 'RAWGREEN-MEAN', 'EXRED-MEAN',
    'EXBLUE-MEAN', 'EXGREEN-MEAN', 'VALUE-MEAN', 'SATURATION-MEAN',
    'HUE-MEAN'
]


data_folder = r'E:\my_project\Kernel_Methods\image_segmentation'

# 读取训练数据，跳过前两行
train_data = pd.read_csv(f'{data_folder}/segmentation.data', skiprows=2, header=0, names=['CLASS'] + feature_names)

# 读取测试数据，跳过前两行
test_data = pd.read_csv(f'{data_folder}/segmentation.test', skiprows=2, header=0, names=['CLASS'] + feature_names)

data = pd.concat([train_data, test_data], axis=0).reset_index(drop=True)

# print(data.head())

# 将类别标签转换为数值
label_encoder = LabelEncoder()
data['CLASS'] = label_encoder.fit_transform(data['CLASS'])

# 分离特征和标签
X = data.drop('CLASS', axis=1)
y = data['CLASS'] # 7个类别，19个属性

print(X.shape,y.shape)

# 将 X 转换为 NumPy 数组
X = X.to_numpy()

# 标准化数据
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 输出目录
output_dir = './output_image_segmentation'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# KLDA可视化
def plot_klda(X_klda, y, title, filename):
    plt.figure(figsize=(8, 6))
    if X_klda.shape[1] > 1:  # 确保有至少两个主成分
        plt.scatter(X_klda[:, 0], X_klda[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
        plt.title(title)
        plt.xlabel('First Component')
        plt.ylabel('Second Component')
        plt.colorbar(label='Class Label')
    else:
        print(f"无法绘制2D图，因为降维结果只有一个主成分。")
    plt.savefig(filename)
    plt.close()

# 可视化原始数据与KLDA降维后的数据对比
def plot_original_vs_klda(X, X_klda, y):
    fig, ax = plt.subplots(1, 2, figsize=(14, 6))

    # 原始数据的二维可视化（选择前两个特征）
    ax[0].scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
    ax[0].set_title("Original Data (First 2 Features)")
    ax[0].set_xlabel('Feature 1')
    ax[0].set_ylabel('Feature 2')

    # KLDA降维后的数据可视化
    ax[1].scatter(X_klda[:, 0], X_klda[:, 1], c=y, cmap=plt.cm.viridis, edgecolors='k', s=50)
    ax[1].set_title("Kernel LDA (2D Projection)")
    ax[1].set_xlabel('1st Component')
    ax[1].set_ylabel('2nd Component')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'original_vs_klda.png'))
    plt.close()

# 绘制不同核函数的效果对比
kernels = ['rbf', 'linear', 'poly', 'sigmoid']
for kernel in kernels:
    klda = KLDA.klda(kernel=kernel)
    X_klda = klda.fit_transform(X, y)
    plot_klda(X_klda, y, f"Kernel LDA with {kernel} kernel", os.path.join(output_dir, f"klda_{kernel}.png"))


lda = KLDA.klda(kernel='rbf',gamma=0.1)
X_klda = lda.fit_transform(X, y)

# 显示原始数据和降维后的数据对比
plot_original_vs_klda(X, X_klda, y)

# 设置不同的gamma值
gamma_values = [0.1, 1.0, 10.0, 100.0]

# 遍历不同的gamma值
for gamma in gamma_values:
    # 创建并训练KLDA模型
    klda_model = KLDA.klda(kernel='rbf', gamma=gamma)
    X_klda = klda_model.fit_transform(X, y)

    # 绘制并保存图像
    title = f"Kernel LDA with RBF Kernel (gamma={gamma})"
    filename = os.path.join(output_dir, f"klda_rbf_gamma_{gamma}.png")
    plot_klda(X_klda, y, title, filename)

# 设置不同的degree和coef0值
degree_values = [2, 3, 4]  # 多项式的度数
coef0_values = [1, 2, 3]   # 多项式核的常数项

# 遍历不同的degree和coef0值
for degree in degree_values:
    for coef0 in coef0_values:
        # 创建并训练KLDA模型
        klda_model = KLDA.klda(kernel='poly', degree=degree, coef0=coef0, n_components=2)
        X_klda = klda_model.fit_transform(X, y)

        # 绘制并保存图像
        title = f"Kernel LDA with Polynomial Kernel (degree={degree}, coef0={coef0})"
        filename = os.path.join(output_dir, f"klda_polynomial_degree_{degree}_coef0_{coef0}.png")
        plot_klda(X_klda, y, title, filename)



print(f"Generated {len(degree_values) * len(coef0_values)} images in the '{output_dir}' folder.")


