import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import os

# 创建输出文件夹
output_dir = './output_rbf'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 生成数据函数
def generate_data(noise_level):
    X = np.linspace(0, 10, 1000).reshape(-1, 1)  # 生成 X 数据
    y = 2 * np.sin(X).ravel() + np.sin(2 * X).ravel() + np.cos(2 * X).ravel()  # 生成真实函数值
    noise = np.random.normal(0, noise_level, X.shape[0])  # 生成噪声
    y_noisy = y + noise  # 添加噪声
    return X, y_noisy

# 定义不同的噪声标准差、不敏感参数和C值
sigma_values = [0.1, 0.3, 0.5, 0.7, 0.9]
epsilon_values = [0.001, 0.01, 0.1]
gamma_values = [0.01, 0.05,0.1, 0.5,1, 10, 100]

# 训练和绘图
plot_count = 1
for sigma in sigma_values:
    for epsilon in epsilon_values:
        for C in gamma_values:
            # 生成带噪声的数据
            X, y_noisy = generate_data(sigma)

            # 划分训练集和测试集
            X_train, X_test, y_train, y_test = train_test_split(X, y_noisy, test_size=0.2, random_state=42)

            # 训练SVR
            svr = SVR(kernel='rbf', gamma=C, epsilon=epsilon)
            svr.fit(X_train, y_train)

            # 预测
            y_pred = svr.predict(X_test)

            # 计算MSE
            mse = mean_squared_error(y_test, y_pred)

            # 绘制实际值与预测值的图像
            plt.figure(figsize=(10, 6))
            plt.scatter(X_test, y_test, color='blue', label='Actual data', s=10)  # 绘制蓝色的实际数据点
            plt.scatter(X_test, y_pred, color='red', label='Predicted data', s=20)  # 绘制红色的预测数据点

            # 连线：只连接与红点最近的红点
            sorted_indices = np.argsort(X_test.ravel())  # 根据 X 排序，方便连接相邻的红点
            X_test_sorted = X_test[sorted_indices]
            y_pred_sorted = y_pred[sorted_indices]

            # 每两个红点之间连线
            for i in range(1, len(X_test_sorted)):
                plt.plot([X_test_sorted[i-1], X_test_sorted[i]], [y_pred_sorted[i-1], y_pred_sorted[i]], color='red', alpha=0.5)

            plt.title(f'SVR Regression\nSigma={sigma}, Epsilon={epsilon}, gamma={C}, MSE={mse:.4f}')
            plt.xlabel('X')
            plt.ylabel('y')
            plt.legend()
            plt.grid(True)

            # 保存图像到output文件夹
            plt.savefig(os.path.join(output_dir, f'result_{plot_count}.png'))
            plt.close()

            plot_count += 1


# 绘制单独的图（C的变化，σ=0.5，ε=0.01）
plt.figure(figsize=(10, 6))
sigma_fixed = 0.5
epsilon_fixed = 0.01

# 使用colormap为每个C值指定不同的颜色
colors = plt.cm.viridis(np.linspace(0, 1, len(gamma_values)))  # 使用viridis色图来生成不同的颜色

for idx, C in enumerate(gamma_values):
    X, y_noisy = generate_data(sigma_fixed)
    X_train, X_test, y_train, y_test = train_test_split(X, y_noisy, test_size=0.4, random_state=42)

    svr = SVR(kernel='rbf', gamma=C,C=1, epsilon=epsilon_fixed)
    svr.fit(X_train, y_train)
    y_pred = svr.predict(X_test)

    # 给每个C值分配一个不同的颜色
    plt.scatter(X_test, y_test, color='blue', label='Actual data' if idx == 0 else "")
    plt.scatter(X_test, y_pred, color=colors[idx], label=f'Predicted data (gamma={C})')

plt.title('SVR Regression for gamma values (σ=0.5, ε=0.01,C=1)')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, 'result_gamma_variations.png'))
plt.close()

print(f'Generated images in the output folder.')